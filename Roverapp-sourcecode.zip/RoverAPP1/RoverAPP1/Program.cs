﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoverApp
{
    class Program
    {
        static void Main(string[] args)
        {

            while (true)
            {
                List<int> maxPoints;
                Console.WriteLine("Enter the upper-right coordinates of the plateau :");
                try
                {
                    maxPoints = Console.ReadLine().Trim().Split(' ').Select(int.Parse).ToList();
                    if (maxPoints.Count != 2)
                    {
                        throw new Exception("Input was not in correct format(X Y)");
                    }

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    continue;
                }

                var roverPos = "";
                var roverCount = 1;
                List<string> validDirections = new List<string> { "N", "S", "E", "N" };

                while (roverCount <= 2)
                {
                    Console.WriteLine($"Enter the Position of Rover {roverCount} :");
                    var startPositions = Console.ReadLine().Trim().Split(' ');
                    Position position = new Position();

                    if (startPositions.Count() == 3)
                    {
                        try
                        {
                            position.X = Convert.ToInt32(startPositions[0]);
                            position.Y = Convert.ToInt32(startPositions[1]);
                            position.Direction = Convert.ToString(startPositions[2]);
                            if (!validDirections.Contains(position.Direction))
                            {
                                throw new Exception("Please Enter a valid Direction ( N | S | E | W )!");
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                            continue;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Input was not in correct format(X Y Direction)");
                        continue;
                    }

                    Console.WriteLine($"Enter the Moves of Rover {roverCount} :");
                    var moves = Console.ReadLine().ToUpper();

                    try
                    {
                        position.StartMoving(maxPoints, moves);
                        //Console.WriteLine($"{position.X} {position.Y} {position.Direction.ToString()}");
                        roverPos += ($"The position of Rover {roverCount} : {position.X} {position.Y} {position.Direction.ToString()}\n");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }

                    roverCount++;
                }

                Console.WriteLine(roverPos);
                Console.WriteLine("Would you like to move the Rovers again? (Type 'Y' to continue, any other key to exit!)");

                if (Console.ReadLine().ToString().ToUpper() != "Y")
                {
                    break;
                }

            }
        }
    }

    public class Position
    {
        public int X;
        public int Y;
        public string Direction;

        public Position()
        {
            X = Y = 0;
            Direction = "N";
        }

        private void Rotate90Left()
        {
            switch (this.Direction)
            {
                case "N":
                    this.Direction = "W";
                    break;
                case "S":
                    this.Direction = "E";
                    break;
                case "E":
                    this.Direction = "N";
                    break;
                case "W":
                    this.Direction = "S";
                    break;
                default:
                    break;
            }
        }

        private void Rotate90Right()
        {
            switch (this.Direction)
            {
                case "N":
                    this.Direction = "E";
                    break;
                case "S":
                    this.Direction = "W";
                    break;
                case "E":
                    this.Direction = "S";
                    break;
                case "W":
                    this.Direction = "N";
                    break;
                default:
                    break;
            }
        }

        private void MoveInSameDirection()
        {
            switch (this.Direction)
            {
                case "N":
                    this.Y += 1;
                    break;
                case "S":
                    this.Y -= 1;
                    break;
                case "E":
                    this.X += 1;
                    break;
                case "W":
                    this.X -= 1;
                    break;
                default:
                    break;
            }
        }

        public void StartMoving(List<int> maxPoints, string moves)
        {
            foreach (var move in moves)
            {
                switch (move)
                {
                    case 'M':
                        this.MoveInSameDirection();
                        break;
                    case 'L':
                        this.Rotate90Left();
                        break;
                    case 'R':
                        this.Rotate90Right();
                        break;
                    default:
                        Console.WriteLine($"Invalid Character {move}");
                        break;
                }

                if (this.X < 0 || this.X > maxPoints[0] || this.Y < 0 || this.Y > maxPoints[1])
                {
                    throw new Exception($"Oops! Position can not be beyond bounderies (0 , 0) and ({maxPoints[0]} , {maxPoints[1]})");
                }
            }
        }
    }
}
